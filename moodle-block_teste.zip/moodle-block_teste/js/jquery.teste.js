$(document).ready(function(){

    // jQuery methods go here...
    alert("hello");
 
 });