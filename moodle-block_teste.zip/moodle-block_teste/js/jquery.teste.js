
!(function($) {
   alert("hello");
})(jQuery);
