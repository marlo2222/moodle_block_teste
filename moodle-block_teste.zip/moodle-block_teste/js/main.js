var myheading = document.querySelector('h1');
myheading.innerHTML = 'hello world';
