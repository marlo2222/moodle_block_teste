//var myheading = document.querySelector('h1');
//myheading.innerHTML = 'hello world';
window.alert(5 + 6);