$(document).ready(function() {
   // var countdown = $('.block-countdown-timer');
});