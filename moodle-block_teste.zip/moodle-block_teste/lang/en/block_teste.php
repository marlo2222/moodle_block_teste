<?php



$string['blockstring'] = 'Block string';
$string['descconfig'] = 'Description of the config section';
$string['descfoo'] = 'Config description';
$string['headerconfig'] = 'Config section header';
$string['setting'] = 'o que deseja fazer';
$string['teste:addinstance'] = 'Add a teste block';
$string['teste:myaddinstance'] = 'Add a teste block to my moodle';
$string['pluginname'] = 'teste';
